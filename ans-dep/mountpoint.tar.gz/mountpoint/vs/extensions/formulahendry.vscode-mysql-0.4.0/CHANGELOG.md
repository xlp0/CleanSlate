## 0.4.0 (2018-04-03)
* [#81](https://github.com/formulahendry/vscode-mysql/issues/81): Upgrade to VS Code's webview API
* [#97](https://github.com/formulahendry/vscode-mysql/pull/97): Escape database and table names

## 0.3.0 (2018-03-12)
* Show query result as HTML table

## 0.2.3 (2018-02-23)
* Add support for executing selected query

## 0.2.2 (2017-12-31)
* [#10](https://github.com/formulahendry/vscode-mysql/issues/10): Add key bindings for 'Run MySQL Query'

## 0.2.1 (2017-12-05)
* Keep original properties when creating connection
* Close the connection after query

## 0.2.0 (2017-12-04)
* Support SSL connection

## 0.1.1 (2017-12-03)
* List columns

## 0.1.0 (2017-11-30)
* Support multiple statement queries

## 0.0.3 (2017-11-26)
* Activate extension when running MySQL query

## 0.0.2 (2017-11-24)
* Better output format: display output as table
* [#2](https://github.com/formulahendry/vscode-mysql/issues/2): Add option to set maximum table count, and increase the dafault count

## 0.0.1 (2017-11-22)
* Initial Release
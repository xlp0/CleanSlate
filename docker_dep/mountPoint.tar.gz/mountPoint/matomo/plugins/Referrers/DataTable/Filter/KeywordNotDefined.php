<?php
/**
 * Matomo - free/libre analytics platform
 *
 * @link https://matomo.org
 * @license http://www.gnu.org/licenses/gpl-3.0.html GPL v3 or later
 *
 */
namespace Piwik\Plugins\Referrers\DataTable\Filter;

use Piwik\DataTable\Row;
use Piwik\DataTable;

class KeywordNotDefined extends DataTable\Filter\ColumnCallbackReplace
{
    /**
     * Constructor.
     *
     * @param DataTable $table The table to eventually filter.
     */
    public function __construct($table)
    {
        parent::__construct($table, 'label', 'Piwik\Plugins\Referrers\API::getCleanKeyword');
    }
}
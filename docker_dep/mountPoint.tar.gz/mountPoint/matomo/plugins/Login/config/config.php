<?php

return array(
    'Piwik\Auth' => DI\create('Piwik\Plugins\Login\Auth')
);